# <img src="./assets/main/profile-pic.png" width="165" height="200" alt="profile picture"> **David Zarecki**<br>


<br>
<br>
<br>

## Junior _**FrontEnd Developer**_

<br>
<br>
<br>

____
### **Contact Information**<br>
**[<img src="https://img.icons8.com/office/23/000000/phonelink-ring--v2.png"/> Phone](https://link-to-tel.herokuapp.com/tel/%2B7%20(968)%20396-3875)** <br>
**[<img src="https://img.icons8.com/color/20/000000/gmail--v2.png"/> Email](mailto:zarecki.david@gmail.com)** <br>
**[<img src="https://img.icons8.com/color/20/000000/whatsapp--v4.png"/> Whatsapp](https://api.whatsapp.com/send?phone=79683963875&text=Hi%20it%20is%20David)** <br>

___
## **About Me** <br>
Born in Lithuania  1985 in capital city of Vilnius. in 94' moved with parents and my brothers to Israel.<br>
in 02' returned to Lithuania, until 12' lived studied and worked in Lithuania. <br>
in 2012 moved to UK Lonodn and lived there until 2018. with HTML I've been introduced in mid 90's when in <br>
Israel in 8th grade we studied IT where we started building our own sites...<br>
but really with the HTML CSS and JavaScript started in 2019 when started my Introduction to Programming  at Udacity Course.<br>since then studying and learning on selflearning basis.
since 2018 I live in Russia have two citizenships, EU and RUS. <br><br>

___
## **Skills** <br>
 &#x2705;HTML (Basic) <br>
 &#x2705;CSS (Basic)<br>
 &#x2705;JavaScript <br>
 &#x2705;Gulp (Basic) <br>
___

## **Code** <br>
8kyu Multiply CodeWars
```
This code does not execute properly. Try to figure out why.

function multiply(a, b){
  a * b
  
  
}

```

```
solution

const a = 1
const b = 1
function multiply(a, b){
  return (a * b)
}
```
___

## **Courses** <br>
**[Udacity](https://confirm.udacity.com/KASGDULU)** Intro Into Programming <br>
___
## **Languages** <br>

rsschool-cv-html
- &#x1F6A9;English (C1 Advanced) [<img src="./img/c1-english.png" width="20" height="20">](https://www.efset.org/cert/s439P4)
- &#x1F6A9;Lithuanian (Native)
- &#x1F6A9;Russian (Spoken, Reading)
- &#x1F6A9;Hebrew (Spoken, Writing, Reading)
- &#x1F6A9;Polish (Basic)
<br>


 &#x1F6A9;English (C1 Advanced) [<img src="./img/c1-english.png" width="20" height="20">](https://www.efset.org/cert/s439P4)<br>
 &#x1F6A9;Lithuanian (Native)<br>
 &#x1F6A9;Russian (Spoken, Reading)<br>
 &#x1F6A9;Hebrew (Spoken, Writing, Reading)<br>
 &#x1F6A9;Polish (Basic)<br>
gh-pages
____

### **Social Media** <br>
**[<img src="https://img.icons8.com/color/20/000000/telegram-app--v5.png"/> Telegram ](https://t.me/SoLoWeJ_ThE_GaMeR)** <br>
**[<img src="https://img.icons8.com/color/20/000000/discord-logo.png"/> Discord](https://discord.gg/JD7VZyNd)** <br>
**[<img src="https://img.icons8.com/color/20/000000/linkedin-2--v2.png"/> Linkedin](https://www.linkedin.com/in/david-zarecki-b72b201a1/)** <br>
**[<img src="https://img.icons8.com/office/20/000000/facebook-new.png"/> FaceBook](https://www.facebook.com/soloweij/)** <br>
**[<img src="https://img.icons8.com/color/20/000000/instagram-new--v2.png"/> Instagram](https://www.instagram.com/madskinnyman/)** <br>
**[<img src="https://img.icons8.com/color/20/000000/youtube-squared.png"/> YouTube](https://www.youtube.com/channel/UCL9ZG_GqkoNmjQEPS8jLDFQ)** <br>
<br>




 <img src="https://licensebuttons.net/l/by-nc-nd/3.0/88x31.png" alt=""> &copy; David Zarecki AKA SoLoWeJ under CC BY-NC-ND